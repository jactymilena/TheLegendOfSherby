

/***************************** Include Files *******************************/
#include "myColorRegister.h"

/************************** Function Definitions ***************************/
