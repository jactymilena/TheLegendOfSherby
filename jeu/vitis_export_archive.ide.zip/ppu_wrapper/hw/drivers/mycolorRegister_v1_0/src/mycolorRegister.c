

/***************************** Include Files *******************************/
#include "mycolorRegister.h"

/************************** Function Definitions ***************************/
