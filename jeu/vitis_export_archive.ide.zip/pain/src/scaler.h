#ifndef __SCALER_H_
#define __SCALER_H_

#include "xvprocss.h"

void configureScaler();
void setScalerInputRes(XVprocSs* vpssPtr);
void setScalerOutputRes(XVprocSs* vpssPtr);

#endif
